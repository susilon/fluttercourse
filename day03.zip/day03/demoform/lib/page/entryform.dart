import 'package:demoform/model/masterbarang.dart';
import 'package:flutter/material.dart';

import '../component.dart';

class EntryForm extends StatefulWidget {
  EntryForm({this.barang});

  MasterBarang barang;

  @override
  _EntryFormState createState() => _EntryFormState();
}

class _EntryFormState extends State<EntryForm> {
  final _formKey = GlobalKey<FormState>();
  var _formValue = Map<String, dynamic>();
  MasterBarang _barang;
  String _valueSatuan;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _barang = widget.barang;
    _valueSatuan = _barang != null ? _barang.satuan : "porsi";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text('Entry Data'),
      ),
      body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                inputTextLeftLabel("Kode",
                    keyboardType: TextInputType.number,
                    initialValue: _barang != null ? _barang.kode : null,
                    maxLength: 5, validator: (value) {
                  if (value.isEmpty) {
                    return "Kode Harus Diisi Mas!";
                  }
                  return null;
                }, callback: (colname, value) {
                  _formValue[colname.toLowerCase()] = value;
                }),
                inputTextLeftLabel("Nama",
                    initialValue: _barang != null ? _barang.nama : null,
                    maxLength: 25, callback: (colname, value) {
                  _formValue[colname.toLowerCase()] = value;
                }),
                inputTextLeftLabel("Keterangan",
                    initialValue: _barang != null ? _barang.keterangan : null,
                    callback: (colname, value) {
                  _formValue[colname.toLowerCase()] = value;
                }),
                inputTextLeftLabel("Harga",
                    keyboardType: TextInputType.number,
                    initialValue: _barang != null
                        ? _barang.harga.toString()
                        : null, validator: (value) {
                  bool numValid = double.tryParse(value) != null;

                  if (!numValid) {
                    return "Harga Harus Diisi Angka Mas!";
                  }
                  return null;
                }, callback: (colname, value) {
                  _formValue[colname.toLowerCase()] = value;
                }),
                dropdownLeftLabel(
                    "Satuan",
                    [
                      {
                        "display": "Porsi",
                        "value": "porsi",
                      },
                      {
                        "display": "Piring",
                        "value": "piring",
                      },
                      {
                        "display": "Gelas",
                        "value": "gelas",
                      },
                      {
                        "display": "Karung",
                        "value": "karung",
                      },
                      {
                        "display": "Bungkus",
                        "value": "bungkus",
                      },
                      {
                        "display": "Gayung",
                        "value": "gayung",
                      },
                    ],
                    hintText: "Pilih Satuan",
                    initialValue: _valueSatuan, onChanged: (value) {
                  setState(() {
                    _valueSatuan = value;
                  });
                  print(value);
                }, onSaved: (value) {
                  _formValue["satuan"] = value;
                  print(value);
                }),
                formButton(() {
                  if (_formKey.currentState.validate()) {
                    _formKey.currentState.save();
                    _formValue['id'] = _barang != null ? _barang.id : null;
                    ;
                    Navigator.pop(context, _formValue);
                  }
                }, Icons.save, "Simpan", Colors.blue, Colors.white),
                formButton(() {
                  _formKey.currentState.reset();
                }, Icons.refresh, "Reset", Colors.orange, Colors.black),
              ],
            ),
          )),
    );
  }
}
