import 'package:demoform/model/masterbarang.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import 'entryform.dart';

class ListBarang extends StatefulWidget {
  ListBarang();

  @override
  _ListBarangState createState() => _ListBarangState();
}

class _ListBarangState extends State<ListBarang> {
  MasterBarangDB _masterBarangDB = MasterBarangDB();
  List<MasterBarang> _listMasterBarang;
  int _count = 0;

  void updateListView() {
    print('update list view');
    final Future<Database> dbFuture = _masterBarangDB.initDb();
    dbFuture.then((database) {
      Future<List<MasterBarang>> listBarangFuture =
          _masterBarangDB.getMasterBarangList();

      listBarangFuture.then((listdata) {
        setState(() {
          print(listdata.length);
          this._listMasterBarang = listdata;
          _count = listdata.length;
        });
      });
    });
  }

  void simpanData(MasterBarang barang) async {
    int result = await _masterBarangDB.insert(barang.toMap());
    if (result > 0) {
      updateListView();
    }
  }

  void deleteData(int id) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Yakin"),
          content: Text("Yakin mau dihapus?"),
          actions: [
            FlatButton(
              child: Text("Jangan"),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            FlatButton(
              child: Text("Ya Udah"),
              onPressed: () async {
                int result = await _masterBarangDB.delete(id);
                Navigator.pop(context);
                if (result > 0) {
                  updateListView();
                }
              },
            ),
          ],
        );
      },
    );
  }

  void editData(MasterBarang dataLama) async {
    var dataDariForm = await Navigator.push(context,
        MaterialPageRoute(builder: (BuildContext context) {
      return EntryForm(
        barang: dataLama,
      );
    }));

    if (dataDariForm != null) {
      var dataBaru = MasterBarang.fromMap(dataDariForm);
      int result = await _masterBarangDB.update(dataBaru.id, dataBaru.toMap());
      if (result > 0) {
        updateListView();
      }
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    updateListView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          // Here we take the value from the MyHomePage object that was created by
          // the App.build method, and use it to set our appbar title.
          title: Text('Entry Data'),
        ),
        body: ListView.builder(
            itemCount: _count,
            itemBuilder: (BuildContext context, int index) {
              var _barang = this._listMasterBarang[index];
              return Card(
                  color: Colors.white,
                  elevation: 2.0,
                  child: ListTile(
                    leading: Icon(Icons.restaurant),
                    onTap: () {
                      editData(_barang);
                    },
                    title: Row(
                      children: [
                        Text('(' + _barang.kode + ')'),
                        SizedBox(
                          width: 7,
                        ),
                        Text(
                          _barang.nama,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_barang.keterangan),
                        Text(
                          'Rp.' + _barang.harga.toString(),
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    trailing: GestureDetector(
                      child: Icon(Icons.delete),
                      onTap: () {
                        deleteData(_barang.id);
                      },
                    ),
                  ));
            }),
        floatingActionButton: FloatingActionButton(
            child: Icon(Icons.add),
            onPressed: () async {
              var dataBarang = await Navigator.push(context,
                  MaterialPageRoute(builder: (BuildContext context) {
                return EntryForm();
              }));

              if (dataBarang != null) {
                //print(dataBarang);
                //var testvar = MasterBarang.fromMap(dataBarang);
                //print(testvar.nama);
                simpanData(MasterBarang.fromMap(dataBarang));
              }
            }));
  }
}
