import 'package:demoform/model/masterbarang.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import 'entryform.dart';

class ListBarang extends StatefulWidget {
  ListBarang();

  @override
  _ListBarangState createState() => _ListBarangState();
}

class _ListBarangState extends State<ListBarang> {
  // koneksi ke database untuk tabel masterbarang
  MasterBarangDB _masterBarangDB = MasterBarangDB();
  // penampung data list barang
  List<MasterBarang> _listMasterBarang;
  // penampung jumlah data di list, default 0
  int _count = 0;

  // fungsi untuk mengupdate data list barang
  void updateListView() {
    print('update list view');
    // memanggil fungsi inisial db di model/dbhelper.dart
    final Future<Database> dbFuture = _masterBarangDB.initDb();

    dbFuture.then((database) {
      // memanggil fungsi getMasterBarangList di model/masterbarang.dart, untuk membaca data dari database
      Future<List<MasterBarang>> listBarangFuture =
          _masterBarangDB.getMasterBarangList();

      // list data dari database dimasukkan ke penampung listbarang, dan count
      listBarangFuture.then((listdata) {
        setState(() {
          print(listdata.length);
          this._listMasterBarang = listdata;
          _count = listdata.length;
        });
      });
    });
  }

  // fungsi untuk menyimpan data ke database
  void simpanData(MasterBarang barang) async {
    int result = await _masterBarangDB.insert(barang.toMap());
    if (result > 0) {
      updateListView();
    }
  }

  // fungsi untuk menghapus data ke database
  void deleteData(int id) async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // tampilkan alert dulu
        return AlertDialog(
          title: Text("Yakin"),
          content: Text("Yakin mau dihapus?"),
          actions: [
            // button batal
            FlatButton(
              child: Text("Jangan"),
              onPressed: () {
                // tutup alert
                Navigator.pop(context);
              },
            ),
            // button confirm
            FlatButton(
              child: Text("Ya Udah"),
              onPressed: () async {
                // delete database
                int result = await _masterBarangDB.delete(id);
                // tutup alert
                Navigator.pop(context);
                if (result > 0) {
                  // refresh list
                  updateListView();
                }
              },
            ),
          ],
        );
      },
    );
  }

  // fungsi edit data
  void editData(MasterBarang dataLama) async {
    // buka halaman entry form, dengan mengirim data barang sebagai parameter
    var dataDariForm = await Navigator.push(context,
        MaterialPageRoute(builder: (BuildContext context) {
      return EntryForm(
        barang: dataLama,
      );
    }));

    // jika ada hasil data dari entry form
    if (dataDariForm != null) {
      // convert data ke tipe masterbarang
      var dataBaru = MasterBarang.fromMap(dataDariForm);
      // update ke database
      int result = await _masterBarangDB.update(dataBaru.id, dataBaru.toMap());
      if (result > 0) {
        // refresh list
        updateListView();
      }
    }
  }

  // fungsi dipanggil saat start
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    // refresh list, membaca database
    updateListView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Master Menu'),
        ),
        // body berupa ListView
        body: ListView.builder(
            itemCount: _count,
            itemBuilder: (BuildContext context, int index) {
              // data barang pada index ke ..
              var _barang = this._listMasterBarang[index];
              // item list berupa Card
              return Card(
                  color: Colors.white,
                  elevation: 2.0,
                  // child Card berupa ListTile
                  child: ListTile(
                    leading: Icon(Icons.restaurant),
                    onTap: () {
                      // saat row pada list di tap, maka panggil fungsi editData
                      editData(_barang);
                    },
                    title: Row(
                      children: [
                        Text('(' + _barang.kode + ')'),
                        SizedBox(
                          width: 7,
                        ),
                        Text(
                          _barang.nama,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_barang.keterangan),
                        Text(
                          'Rp.' + _barang.harga.toString(),
                          style: TextStyle(
                              color: Colors.red, fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    // trailing bisa ditap dengan fungsi yang berbeda menggunakan GestureDetector
                    trailing: GestureDetector(
                      child: Icon(Icons.delete),
                      onTap: () {
                        // dimana fungsi yang dipanggil disini adalah deleteData
                        deleteData(_barang.id);
                      },
                    ),
                  ));
            }),
        // tombol untuk menambah data baru
        floatingActionButton: FloatingActionButton(
            child: Icon(Icons.add),
            onPressed: () async {
              // membuka entry form tanpa parameter akan menampilkan form yang kosong
              var dataBarang = await Navigator.push(context,
                  MaterialPageRoute(builder: (BuildContext context) {
                return EntryForm();
              }));

              // data yang diinput dari form
              if (dataBarang != null) {
                // panggil fungsi simpanData dengan parameter data dari form
                simpanData(MasterBarang.fromMap(dataBarang));
              }
            }));
  }
}
