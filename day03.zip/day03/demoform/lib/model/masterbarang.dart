import 'package:demoform/model/dbhelper.dart';

// class untuk menampung data dari tabel dengan tipe masterbaramg
class MasterBarang {
  int id;
  String kode;
  String nama;
  String keterangan;
  int harga;
  String satuan;

  // constructor
  MasterBarang(this.kode, this.nama, this.harga, this.keterangan, this.satuan);

  // converter dari class masterbarang ke map
  Map<String, dynamic> toMap() {
    Map<String, dynamic> _map = Map<String, dynamic>();

    _map['id'] = this.id;
    _map['kode'] = this.kode;
    _map['nama'] = this.nama;
    _map['keterangan'] = this.keterangan;
    _map['harga'] = this.harga;
    _map['satuan'] = this.satuan;

    return _map;
  }

  // converter dari map ke class masterbarang
  MasterBarang.fromMap(Map<String, dynamic> map) {
    print(map);

    this.id = map['id'];
    this.kode = map['kode'];
    this.nama = map['nama'];
    this.keterangan = map['keterangan'];
    this.harga = int.parse(map['harga'].toString());
    this.satuan = map['satuan'];
  }
}

// class untuk mengakses data masterbarang di database, di extend ke DBHelper
class MasterBarangDB extends DBHelper {
  String tableName = 'masterbarang';

  // constructor MasterBarangDB dengan parameter tableName (optional)
  MasterBarangDB({tableName});

  // fungsi untuk mengambil data barang ke database
  Future<List<MasterBarang>> getMasterBarangList() async {
    var listBarangMap = await select('nama');
    List<MasterBarang> _listBarang = List<MasterBarang>();
    for (int i = 0; i < listBarangMap.length; i++) {
      _listBarang.add(MasterBarang.fromMap(listBarangMap[i]));
    }
    return _listBarang;
  }
}
