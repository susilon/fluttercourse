import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

// class untuk koneksi ke db sqlite
class DBHelper {
  static Database _database;
  String tableName;

  // constructor, dengan parameter tabelName (optional)
  DBHelper({this.tableName});

  // fungsi untuk create table pertama kali
  void createDb(Database db, int version) async {
    await db.execute('''
     CREATE TABLE masterbarang (
       id INTEGER PRIMARY KEY AUTOINCREMENT,
       kode TEXT,
       nama TEXT,
       keterangan TEXT,
       harga INTEGER,
       satuan TEXT)
       ''');
  }

  Future<Database> initDb() async {
    // lokasi path file database
    Directory directory = await getApplicationDocumentsDirectory();
    String path = directory.path + 'localdb.db';

    // open database, kalau belum ada create
    return openDatabase(path, version: 1, onCreate: createDb);
  }

  // database lazy loader
  Future<Database> get database async {
    if (_database == null) {
      _database = await initDb();
    }
    return _database;
  }

  // **********
// CRUD
// **********

//create data
  Future<int> insert(Map object) async {
    Database db = await this.database;
    int count = await db.insert(this.tableName, object);
    return count;
  }

// read data
  Future<List<Map<String, dynamic>>> select(String orderBy) async {
    Database db = await this.database;
    var mapList = await db.query(this.tableName, orderBy: orderBy);
    return mapList;
  }

//update data dengan parameter id
  Future<int> update(int id, Map object) async {
    Database db = await this.database;
    int count =
        await db.update(this.tableName, object, where: 'id=?', whereArgs: [id]);
    return count;
  }

//delete data dengan parameter id
  Future<int> delete(int id) async {
    Database db = await this.database;
    int count = await db.delete(this.tableName, where: 'id=?', whereArgs: [id]);
    return count;
  }
}
