import 'package:dropdown_formfield/dropdown_formfield.dart';
import 'package:flutter/material.dart';

Widget inputText(String _text) {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
    child: TextFormField(
      decoration:
          InputDecoration(labelText: _text, border: OutlineInputBorder()),
    ),
  );
}

Widget inputTextTopLabel(String _text) {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_text),
        SizedBox(
          height: 10,
        ),
        TextFormField(
          decoration: InputDecoration(border: OutlineInputBorder()),
        )
      ],
    ),
  );
}

Widget inputTextLeftLabel(String _text,
    {TextEditingController controller,
    TextInputType keyboardType,
    FormFieldValidator validator,
    int maxLength,
    String initialValue,
    Function(String, String) callback}) {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
    child: Row(
      children: [
        Container(
          child: Text(_text),
          width: 100,
        ),
        Expanded(
          child: TextFormField(
              onSaved: (value) {
                print("$_text: $value");
                if (callback != null) callback(_text, value);
              },
              validator: validator,
              controller: controller,
              maxLength: maxLength,
              initialValue: initialValue,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(border: OutlineInputBorder()),
              keyboardType: keyboardType),
        )
      ],
    ),
  );
}

Widget dropdownLeftLabel(String _text, List<dynamic> _dataSource,
    {String hintText,
    String initialValue,
    Function onSaved,
    Function onChanged}) {
  return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: Row(children: [
        Container(
          child: Text(_text),
          width: 100,
        ),
        Expanded(
            child: DropDownFormField(
          //titleText: _text,
          hintText: hintText,
          value: initialValue,
          onSaved: (value) {
            if (onSaved != null) onSaved(value);
          },
          onChanged: (value) {
            if (onChanged != null) onChanged(value);
          },
          dataSource: _dataSource,
          textField: 'display',
          valueField: 'value',
          inputDecoration: InputDecoration(
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(vertical: 5, horizontal: 7)),
        ))
      ]));
}

Widget formButton(Function _onPressed, IconData _icon, String _text,
    Color _color, Color _labelColor) {
  return Container(
    padding: EdgeInsets.symmetric(vertical: 5),
    width: 200,
    child: RaisedButton.icon(
      color: _color,
      padding: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      onPressed: _onPressed,
      icon: Icon(
        _icon,
        color: _labelColor,
      ),
      label: Text(
        _text,
        style: TextStyle(color: _labelColor),
      ),
    ),
  );
}
