## [0.1.3] - 09/21/2020

* Bugfix: Long texts will be cropped.
  
Thanks to [Kevin Schmidt](https://github.com/schmidt-kevin). Merged pull request [#16](https://github.com/cetorres/dropdown_formfield/pull/16).

## [0.1.2] - 04/13/2020

* Added initialValue to the constructor to allow pass it on the widget creation.
  
## [0.1.1] - 09/27/2019

* Changed README.

## [0.1.0] - 03/26/2019

* First release.
